package com.example.doancoso3.model

data class Job(
    val userId: Int,
    val tenCongViec: String,
    val ngayBatDau: String,
    val hinhThuc: String,
    val mucDich: String
)
