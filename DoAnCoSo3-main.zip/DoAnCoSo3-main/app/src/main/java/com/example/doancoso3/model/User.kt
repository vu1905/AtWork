package com.example.doancoso3.model

data class User(
    val email: String,
    val password: String
)
