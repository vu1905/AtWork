package com.example.doancoso3.model

data class WorkShifts(
    val id: String,
    val name: String,
    var salary: Int,
    var isSelected: Boolean = false
)
