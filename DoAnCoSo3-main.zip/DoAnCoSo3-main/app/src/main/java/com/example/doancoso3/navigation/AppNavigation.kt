package com.example.doancoso3.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.doancoso3.view.ChooseWorkShift
import com.example.doancoso3.view.CreateNewJob
import com.example.doancoso3.view.HomeView
import com.example.doancoso3.view.LoginView
import com.example.doancoso3.view.RegisterView

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login_view") {
        composable("login_view") {
            LoginView(navController)
        }
        composable("register_view") {
            RegisterView(navController)
        }
        composable ("home_view"){
            HomeView(navController)
        }
        composable ("create_new_job"){
            CreateNewJob(navController)
        }
        composable("choose_work_shift/{jobName}") { backStackEntry ->
            val jobName = backStackEntry.arguments?.getString("jobName") ?: ""
            ChooseWorkShift(navController, jobName = jobName)
        }
    }
}