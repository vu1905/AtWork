package com.example.doancoso3.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class DangKyDb {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    fun DangKy(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if(task.isSuccessful) {
                    val user = auth.currentUser?.uid

                    val userData = hashMapOf(
                        "email" to email,
                        "password" to password
                    )

                    user?.let {
                        db.collection("users").document(it).set(userData)
                            .addOnSuccessListener {
                                onResult(true, null)
                            }
                    }
                } else {
                    onResult(false, "Đăng ký không thành công!")
                }
            }
    }
}