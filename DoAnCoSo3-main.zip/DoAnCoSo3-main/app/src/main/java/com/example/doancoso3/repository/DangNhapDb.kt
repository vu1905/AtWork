package com.example.doancoso3.repository

import com.google.firebase.auth.FirebaseAuth

class DangNhapDb {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    fun DangNhap(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    onResult(true, null)
                } else {
                    onResult(false, "Đăng nhập không thành công!")
                }
            }
    }

    fun logOut() {
        return auth.signOut()
    }
}