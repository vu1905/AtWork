package com.example.doancoso3.repository

import com.example.doancoso3.model.Job
import com.example.doancoso3.model.WorkShifts
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class JobRepository {
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

//    fun saveJob(job: Job){
//        val jobDocRef = jobCollection.document(job.userId.toString())
//        jobDocRef.set(job)
//    }
//
//    fun saveWorkShifts(userId: Int, workshifts: WorkShifts){
//        val workShiftCollection = jobCollection.document(userId.toString()).collection("workshifts")
//        workShiftCollection.document(workshifts.shiftId.toString()).set(workshifts)
//    }

    fun saveJob(
        jobName: String,
        mucDich: String,
        hinhThuc: String,
        ngayBatDau: String
    ) {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            val jobsCollection = db.collection("users")
                .document(userId)
                .collection("jobs")

            val jobData = hashMapOf(
                "mucDich" to mucDich,
                "hinhThuc" to hinhThuc,
                "ngayBatDau" to ngayBatDau
            )
            jobsCollection.document(jobName).set(jobData)
        }
    }

    fun saveWorkShifts(jobName: String, selectedShifts: List<WorkShifts>) {
        val userId = auth.currentUser?.uid ?: return

        val workShiftsCollection = db.collection("users")
            .document(userId)
            .collection("jobs")
            .document(jobName)
            .collection("workshifts")

        for (shift in selectedShifts) {
            val workshiftData = hashMapOf("salary" to shift.salary)
            workShiftsCollection.document(shift.name).set(workshiftData)
        }
    }
}