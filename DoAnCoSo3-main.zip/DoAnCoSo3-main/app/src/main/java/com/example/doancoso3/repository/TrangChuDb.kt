package com.example.doancoso3.repository

import com.google.firebase.auth.FirebaseAuth

class TrangChuDb {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    fun getCurrentUserId(): String? {
        return auth.currentUser?.uid
    }

    fun getUserEmail(): String {
        return auth.currentUser?.email ?: ""
    }
}