//package com.example.doancoso3.repository
//
//import com.example.doancoso3.model.User
//import com.google.firebase.firestore.FirebaseFirestore
//import com.google.firebase.firestore.Query
//import kotlin.jvm.java
//
//class UserRepository {
//    //Xu li dang ky
//    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
//    private val userCollection = db.collection("users")
//
//    fun saveUser(user: User) {
//        val userDocRef = userCollection.document(user.userId.toString())
//        userDocRef.set(user)
//    }
//
//    fun getNextUserId(onSuccess: (Int) -> Unit, onFailure: (Exception) -> Unit) {
//        userCollection.orderBy("userId", Query.Direction.DESCENDING)
//            .limit(1)
//            .get()
//            .addOnSuccessListener { queryUser ->
//                if(queryUser.isEmpty) {
//                    onSuccess(1)
//                } else {
//                    val lastUser = queryUser.documents[0].toObject(User::class.java)
//                    val nextUserId = (lastUser?.userId ?: 0) + 1
//                    onSuccess(nextUserId)
//                }
//            }
//            .addOnFailureListener { exception ->
//                onFailure(exception)
//            }
//    }
//
//    fun getEmail(
//        email: String,
//        password: String,
//        onSuccess: (User) -> Unit,
//        onFailure: (String) -> Unit
//    ) {
//        userCollection.whereEqualTo("email", email).get()
//            .addOnSuccessListener { querySnapshot ->
//                if(!querySnapshot.isEmpty){
//                    val user = querySnapshot.documents[0].toObject(User::class.java)
//                    if(user != null && user.password == password){
//                        onSuccess(user)
//                    } else {
//                        onFailure("Mật khẩu không chính xác")
//                    }
//                } else {
//                    onFailure("Email không tồn tại")
//                }
//            }
//            .addOnFailureListener { exception ->
//                onFailure(exception.message ?: "Lỗi đăng nhập không thành công")
//            }
//    }
//}