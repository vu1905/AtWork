package com.example.doancoso3.view

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.doancoso3.repository.JobRepository
import com.example.doancoso3.viewmodel.JobViewModel
import androidx.compose.foundation.lazy.items


@Composable
fun TopTitleWorkShift(
    navController: NavController,
    viewModel: JobViewModel = viewModel(),
    repository: JobRepository = JobRepository(),
    jobName: String
){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceAround
    ){
        Text(
            text = "Trở lại",
            fontSize = 16.sp,
            modifier = Modifier
                .padding(vertical = 15.dp)
                .clickable{
                    navController.popBackStack()
                }
        )
        Text(
            text = "Tạo ca làm việc",
            fontSize = 19.sp,
            fontWeight = FontWeight.W500
        )
        Text(
            text = "Hoàn thành",
            fontSize = 16.sp,
            color = Color.Blue,
            modifier = Modifier.clickable{
                val selectedShifts = viewModel.getSelectedShifts()
                repository.saveWorkShifts(jobName, selectedShifts)
                navController.navigate("home_view")
            }
        )
    }
}

@Composable
fun WorkShiftItem(
    viewModel: JobViewModel = JobViewModel(),
    shiftId: String,
    workShift: String,
    price: Int,
    onPriceChange: (Int) -> Unit,
){
    var enableTextField by remember { mutableStateOf(false) }
    var errCheckbox by remember { mutableStateOf("") }
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 5.dp)
            .background(Color.White, RoundedCornerShape(15.dp))
            .clickable{
                enableTextField = !enableTextField
                errCheckbox = if(enableTextField == true)
                    "* Vui lòng nhập số tiền mỗi ca"
                else ""
                viewModel.onSelectShift(shiftId, price)
            }
            .border(
                2.dp,
                if(enableTextField == false) Color.Transparent else Color.Blue,
                RoundedCornerShape(15.dp)
            ),

    ){
        Column (
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ){
            Row (modifier = Modifier.fillMaxWidth()){
                Text(
                    text = workShift,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(5.dp))
                if(price == 0) errCheckbox else errCheckbox = ""
                Text(
                    text = errCheckbox,
                    fontSize = 16.sp,
                    color = Color.Red
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Số tiền mỗi ca",
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = price.toString(),
                onValueChange = { input ->
                    val inputPrice = input.toIntOrNull() ?: 0
                    onPriceChange(inputPrice)
                },
                enabled = enableTextField,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = Color(0xFFFFCC66),
                    focusedBorderColor = Color.Gray
                ),
                trailingIcon = {
                    Text(
                        text = "VND",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                },
                shape = RoundedCornerShape(10.dp)
            )
        }
    }
}

@Composable
fun ListWorkShiftItem(viewModel: JobViewModel = viewModel()) {
    LazyColumn(modifier = Modifier.fillMaxWidth()) {
        items(viewModel.workShifts) { shift ->
            WorkShiftItem(
                shiftId = shift.id,
                workShift = shift.name,
                price = shift.salary,
                onPriceChange = { viewModel.onSalaryChange(shift.id, it) },
                viewModel = viewModel
            )
        }
    }
}


@Composable
fun ChooseWorkShift(
    navController: NavController,
    jobName: String
){
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAAFFFFCC))
    ){
        TopTitleWorkShift(
            navController,
            jobName = jobName
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "Ca làm việc có sẵn",
            fontWeight = FontWeight.W600,
            color = Color.Gray,
            modifier = Modifier.padding(start = 20.dp, bottom = 10.dp)
        )
        ListWorkShiftItem()
    }
}
