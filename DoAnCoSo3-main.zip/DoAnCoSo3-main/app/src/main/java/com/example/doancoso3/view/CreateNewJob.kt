package com.example.doancoso3.view

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.doancoso3.R
import com.example.doancoso3.viewmodel.JobViewModel

@Composable
fun TopTitleCNWS(
    navController: NavController,
    onClicked: () -> Unit
){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceAround
    ){
        Text(
            text = "Đóng",
            fontSize = 16.sp,
            modifier = Modifier
                .padding(vertical = 15.dp)
                .clickable{
                    navController.popBackStack()
                }
        )
        Text(
            text = "Tạo công việc mới",
            fontSize = 19.sp,
            fontWeight = FontWeight.W500
        )
        Text(
            text = "Tiếp tục",
            fontSize = 16.sp,
            color = Color.Blue,
            modifier = Modifier.clickable{
                onClicked()
            }
        )
    }
}

@Composable
fun JobNameInput(
    viewModel: JobViewModel = viewModel()
){
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ){
        Row (
            modifier = Modifier.fillMaxWidth()
        ){
            Text(
                text = "Tên công việc",
                fontSize = 15.sp,
                fontWeight = FontWeight.W500
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = viewModel.errMessageJobName,
                fontSize = 15.sp,
                color = Color.Red
            )
        }
        OutlinedTextField(
            value = viewModel.jobName,
            onValueChange = { viewModel.jobName = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
//                .height(50.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White,
                focusedBorderColor = Color.Black
            ),
            trailingIcon = {
                Image(
                    painter = painterResource(R.drawable.job),
                    contentDescription = "Job",
                )
            },
            shape = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
fun DateStartJobInput(viewModel: JobViewModel = viewModel()){
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
    ){
        Text(
            text = "Ngày bắt đầu công việc",
            fontSize = 15.sp,
            fontWeight = FontWeight.W500
        )
        OutlinedTextField(
            value = viewModel.getToday,
            onValueChange = { it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
//                .height(50.dp),
            enabled = false,
            trailingIcon = {
                Icon(
                    imageVector = Icons.Filled.CalendarMonth,
                    contentDescription = "Lịch"
                )
            },
            shape = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
fun ListOptionJob(viewModel: JobViewModel = viewModel()){
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ){
        Row (modifier = Modifier.fillMaxWidth()){
            Text(
                text = "Mục đích chấm công",
                fontSize = 15.sp,
                fontWeight = FontWeight.W500
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = viewModel.errMesageOptionJob,
                fontSize = 15.sp,
                color = Color.Red
            )
        }
        OptionItem(
            nameType = "Chấm công cho cá nhân",
            decribe = "Bạn sẽ tự chấm công cho riêng cá nhân bạn",
            selected = "Chấm công cho cá nhân",
            selectedOption = viewModel.selectedOption,
            onSelectedOption = { viewModel.selectedOption = it }
        )
        OptionItem(
            nameType = "Chấm công cho nhân viên",
            decribe = "Với tư cách chủ, bạn sẽ chấm công cho nhân viên của bạn",
            selected = "Chấm công cho nhân viên",
            selectedOption = viewModel.selectedOption,
            onSelectedOption = { viewModel.selectedOption = it }
        )
    }
}

@Composable
fun OptionItem(
    nameType: String,
    decribe: String,
    selected: String,
    selectedOption: String,
    onSelectedOption: (String) -> Unit
){
    Row (
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .background(Color.White, RoundedCornerShape(15.dp))
            .border(
                2.dp,
                if(selectedOption == selected) Color.Blue else Color.Transparent,
                RoundedCornerShape(15.dp)
            )
            .clickable{
                onSelectedOption(selected)
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ){
        Column (
            modifier = Modifier
                .padding(start = 20.dp, top = 20.dp, bottom = 20.dp)
                .weight(5f)
        ){
            Text(
                text = nameType,
                fontSize = 16.sp,
                fontWeight = FontWeight.W500
            )
            Text(
                text = "Mô tả: $decribe",
                fontSize = 15.sp,
                softWrap = true
            )
        }
        RadioButton(
            selected = selectedOption == selected,
            onClick = {
                onSelectedOption(selected)
            },
            colors = RadioButtonDefaults.colors(
                selectedColor = Color.Blue
            )
        )
    }
}

@Composable
fun ListOptionTimekeeping(
    viewmodel: JobViewModel = viewModel()
){
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ){
        Row (modifier = Modifier.fillMaxWidth()){
            Text(
                text = "Hình thức chấm công",
                fontSize = 15.sp,
                fontWeight = FontWeight.W500
            )
            var errMesageOptionTimekeeping by remember { mutableStateOf("* Bạn chưa có lựa chọn nào") }
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = errMesageOptionTimekeeping,
                fontSize = 15.sp,
                color = Color.Red
            )
        }
        TimekeepingOptionItem(
            timekeepingType = "Chấm công theo ngày",
            timekeepingDecribe = "Chấm cả ngày, chấm nửa ngày,...",
            selectedTimekeeping =  "Chấm công theo ngày",
            selectedOptionTimekeeping = viewmodel.selectedOptionTimekeeping,
            onSelectedOptionTimekeeping = { viewmodel.selectedOptionTimekeeping = it }
        )
        TimekeepingOptionItem(
            timekeepingType = "Chấm công theo ca",
            timekeepingDecribe = "Chấm ca sáng, ca chiều, ca tối,...",
            selectedTimekeeping =  "Chấm công theo ca",
            selectedOptionTimekeeping = viewmodel.selectedOptionTimekeeping,
            onSelectedOptionTimekeeping = { viewmodel.selectedOptionTimekeeping = it }
        )
    }
}

@Composable
fun TimekeepingOptionItem(
    timekeepingType: String,
    timekeepingDecribe: String,
    selectedTimekeeping: String,
    selectedOptionTimekeeping: String,
    onSelectedOptionTimekeeping: (String) -> Unit
){
    Row (
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .background(Color.White, RoundedCornerShape(15.dp))
            .border(
                2.dp,
                if(selectedOptionTimekeeping == selectedTimekeeping) Color.Blue else Color.Transparent,
                RoundedCornerShape(15.dp)
            )
            .clickable{
                onSelectedOptionTimekeeping(selectedTimekeeping)
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ){
        Column (
            modifier = Modifier
                .padding(start = 20.dp, top = 20.dp, bottom = 20.dp)
                .weight(5f)
        ){
            Text(
                text = timekeepingType,
                fontSize = 16.sp,
                fontWeight = FontWeight.W500
            )
            Text(
                text = "Mô tả: $timekeepingDecribe",
                fontSize = 15.sp,
                softWrap = true
            )
        }
        RadioButton(
            selected = selectedOptionTimekeeping == selectedTimekeeping,
            onClick = {
                onSelectedOptionTimekeeping(selectedTimekeeping)
            },
            colors = RadioButtonDefaults.colors(
                selectedColor = Color.Blue
            )
        )
    }
}

@Composable
fun CreateNewJob(
    navController: NavController,
    viewModel: JobViewModel = viewModel()
){
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAAFFFFCC))
    ){
        TopTitleCNWS(
            navController,
            onClicked = {
                if(viewModel.CreateNewJob()) {
                    var jobName = viewModel.jobName
                    viewModel.saveJob()

                    when(viewModel.selectedOption) {
                        "Chấm công cho cá nhân" -> {
                            when(viewModel.selectedOptionTimekeeping) {
                                "Chấm công theo ngày" -> navController.navigate("create_work_day")
                                "Chấm công theo ca" -> navController.navigate("choose_work_shift/${Uri.encode(jobName)}")

                            }
                        }
                        "Chấm công cho nhân viên" -> {
                            when(viewModel.selectedOptionTimekeeping) {
                                "Chấm công theo ngày" -> navController.navigate("create_work_day_for_staff")
                                "Chấm công theo ca" -> navController.navigate("create_work_shifts_for_staff")
                            }
                        }
                    }
                } else {
                    return@TopTitleCNWS
                }
            }
        )
        JobNameInput()
        DateStartJobInput()
        LazyColumn (modifier = Modifier.fillMaxWidth()){
            item {
                ListOptionJob()
                ListOptionTimekeeping()
            }
        }
    }
}