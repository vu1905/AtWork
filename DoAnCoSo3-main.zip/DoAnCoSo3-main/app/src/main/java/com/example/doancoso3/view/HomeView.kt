package com.example.doancoso3.view

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DoubleArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.doancoso3.R
import com.example.doancoso3.viewmodel.TrangChuViewModel

@Composable
fun TopTitleHomeView(
    navController: NavController,
    viewModel: TrangChuViewModel = viewModel()
){
    val email = remember { viewModel.getUserEmail() }
    Row (
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ){
        Column {
            Text(
                text = "Xin chào $email",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Hôm nay: 21/03/2025",
                fontSize = 16.sp
            )
        }

        IconButton(
            modifier = Modifier
                .size(40.dp),
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = Color.Blue
            ),
            onClick = {
                navController.navigate("create_new_job")
            }
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Thêm công việc",
                tint = Color.White,
//                modifier = Modifier.clip(shape = RoundedCornerShape(8.dp))
            )
        }
    }
}

@Composable
fun ListJob(){
    LazyColumn (
        modifier = Modifier.fillMaxWidth()
    ){
        item {
            JobItem()
            JobItem()
        }
    }
}

@Composable
fun JobItem(){
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .background(Color.White, shape = RoundedCornerShape(10.dp))
            .clickable {

            }
    ){
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ){
            Text(
                text = "HighLand Coffee",
                fontWeight = FontWeight.W500,
                fontSize = 20.sp
            )
            Image(
                painter = painterResource(id = R.drawable.user),
                contentDescription = "user_icon",
                modifier = Modifier.size(20.dp)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ){
            Text(
                text = "Ngày bắt đầu: 03/05/2025",
                fontSize = 16.sp
            )
            Text(
                text = "Đang diễn ra",
                fontSize = 16.sp,
                color = Color.Blue
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 5.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Chấm công theo ca",
                fontSize = 16.sp,
                fontWeight = FontWeight.W500,
                color = Color.Red,
                fontStyle = FontStyle.Italic
            )
            Icon(
                imageVector = Icons.Filled.DoubleArrow,
                contentDescription = "Chi tiết",
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun BottomHomeView(modifier: Modifier){
    Row (
        modifier.fillMaxWidth()
            .background(Color.White)
            .height(70.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ){
        Column (
            modifier = Modifier
                .weight(1f)
                .height(70.dp)
                .clickable{

                },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ){
            Image(
                painter = painterResource(R.drawable.homescreen),
                contentDescription = "home_screen",
                modifier.size(20.dp)
            )
            Text(
                text = "Trang chủ",
                fontWeight = FontWeight.W500,
                fontSize = 14.sp
            )
        }

        Column (
            modifier = Modifier
                .weight(1f)
                .height(70.dp)
                .clickable{

                },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ){
            Image(
                painter = painterResource(R.drawable.myinfor),
                contentDescription = "cá nhân",
                modifier.size(20.dp)
            )
            Text(
                text = "Cá nhân",
                fontWeight = FontWeight.W500,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun HomeView(navController: NavController){
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAAFFFFCC))
    ) {
        Column {
            TopTitleHomeView(navController)
            Text(
                text = "Công việc gần đây",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.DarkGray,
                modifier = Modifier.padding(start = 20.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            ListJob()
        }
        BottomHomeView(
            modifier = Modifier
                .align(Alignment.BottomCenter)
        )
    }
}