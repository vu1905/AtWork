package com.example.doancoso3.view

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavController
import com.example.doancoso3.R
import com.example.doancoso3.viewmodel.LoginViewModel

@Composable
fun TopTitle(){
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 80.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(
            text = "Chào mừng trở lại!",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "Ứng dụng chấm công hàng đầu Việt Nam!",
            fontSize = 18.sp
        )
    }
}

@Composable
fun LoginForm(viewModel: LoginViewModel = viewModel()){
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 30.dp, start = 20.dp, end = 20.dp),

    ) {
        Text(
            text = viewModel.errMessageLogin,
            fontSize = 16.sp,
            color = Color.Red
        )
        OutlinedTextField(
            value = viewModel.email,
            onValueChange = { viewModel.email = it },
            placeholder = {
                Text(
                    text = "Email",
                    fontWeight = FontWeight.W500,
                    fontSize = 16.sp
                )
            },
            modifier = Modifier
                .fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Color.Black
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        var showPassword by remember { mutableStateOf(false) }

        OutlinedTextField(
            value = viewModel.password,
            onValueChange = { viewModel.password = it },
            placeholder = {
                Text(
                    text = "Mật khẩu",
                    fontWeight = FontWeight.W500,
                    fontSize = 16.sp
                )
            },
            visualTransformation = if(showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth(),
            trailingIcon = {
                Icon(
                    imageVector = if(showPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                    contentDescription = null,
                    modifier = Modifier.clickable {
                        showPassword = !showPassword
                    }
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Color.Black
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row (
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Text(
                text = "Quên mật khẩu?",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.Blue,
                modifier = Modifier.clickable {

                }
            )
        }
    }
}

@Composable
fun LoginButton(
    navController: NavController,
    viewModel: LoginViewModel = viewModel()
){
    Button(
        modifier = Modifier
            .fillMaxWidth()
            .height(65.dp)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFFFF0000),
        ),
        onClick = {
            viewModel.login()
            if(viewModel.checkedLogin == true) {
                navController.navigate("home_view")
            }
        }
    ) {
        Text(
            text = "Đăng nhập",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
    }
}

@Composable
fun LoginWithGoogle(){
    Button(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(2.dp, Color.Gray),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
        ),
        onClick = {

        }
    ) {
        Row (
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ){
            Image(
                painter = painterResource(R.drawable.google),
                contentDescription = "Google"
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "Đăng nhập với Google",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.Black
            )
        }
    }
}

@Composable
fun LoginWithApple(){
    Button(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(2.dp, Color.Gray),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
        ),
        onClick = {

        }
    ) {
        Row (
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ){
            Image(
                painter = painterResource(R.drawable.apple),
                contentDescription = "Apple"
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "Đăng nhập với Apple",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.Black
            )
        }
    }
}

@Composable
fun LoginWithFacebook(){
    Button(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(2.dp, Color.Gray),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
        ),
        onClick = {

        }
    ) {
        Row (
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ){
            Image(
                painter = painterResource(R.drawable.facebook),
                contentDescription = "Facebook"
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "Đăng nhập với Facebook",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.Black
            )
        }
    }
}

@Composable
fun ButtonToSignup(navController: NavController) {
    Row (
        modifier = Modifier
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Không có tài khoản?",
            fontSize = 17.sp
        )

        Spacer(modifier = Modifier.width(5.dp))

        Text(
            text = "Đăng ký ngay",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Blue,
            modifier = Modifier.clickable {
                navController.navigate("register_view")
            }
        )
    }
}

@Composable
fun LoginView(
    navController: NavController,
    viewModel: LoginViewModel = viewModel()
) {
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAAFFFFCC))
    ) {
        TopTitle()
        LoginForm()
        LoginButton(navController)
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ){
            HorizontalDivider(
                modifier = Modifier
                    .weight(1f) // Chiếm hết phần còn lại
                    .height(1.dp),
                color = Color.Gray
            )
            Text(
                text = "Hoặc bạn cũng có thể",
                modifier = Modifier.padding(horizontal = 8.dp),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.DarkGray
            )
            HorizontalDivider(
                modifier = Modifier
                    .weight(1f)
                    .height(1.dp),
                color = Color.Gray
            )
        }
        LoginWithGoogle()
        LoginWithApple()
        LoginWithFacebook()
        ButtonToSignup(navController)
    }
}