package com.example.doancoso3.view

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.doancoso3.viewmodel.RegisterViewModel

@Composable
fun TopTitleRegister(){
    Text(
        text = "Đăng ký tài khoản",
        fontSize = 25.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 50.dp),
        textAlign = TextAlign.Center
    )
}

@Composable
fun RegisterForm(viewModel: RegisterViewModel = viewModel()){
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
    ){
        OutlinedTextField(
            value = viewModel.email,
            onValueChange = { viewModel.email = it },
            placeholder = {
                Text(
                    text = "Email",
                    fontWeight = FontWeight.W500,
                    fontSize = 16.sp
                )
            },
            modifier = Modifier
                .fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Color.Black
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        var showPassword by remember { mutableStateOf(false) }

        OutlinedTextField(
            value = viewModel.password,
            onValueChange = { viewModel.password = it },
            placeholder = {
                Text(
                    text = "Mật khẩu",
                    fontWeight = FontWeight.W500,
                    fontSize = 16.sp
                )
            },
            modifier = Modifier
                .fillMaxWidth(),
            visualTransformation = if(showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                Icon(
                    imageVector = if(showPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                    contentDescription = null,
                    modifier = Modifier.clickable {
                        showPassword = !showPassword
                    }
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Color.Black
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = viewModel.checkPassword,
            onValueChange = { viewModel.checkPassword = it },
            placeholder = {
                Text(
                    text = "Nhập lại mật khẩu",
                    fontWeight = FontWeight.W500,
                    fontSize = 16.sp
                )
            },
            modifier = Modifier
                .fillMaxWidth(),
            visualTransformation = if(showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                Icon(
                    imageVector = if(showPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                    contentDescription = null,
                    modifier = Modifier.clickable {
                        showPassword = !showPassword
                    }
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Color.Black
            ),
            shape = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
fun RegisterButton(
    navController: NavController,
    viewModel: RegisterViewModel = viewModel()
){
    Button(
        modifier = Modifier
            .fillMaxWidth()
            .height(65.dp)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFFFF0000),
        ),
        onClick = {
            viewModel.DangKy()
            if (viewModel.isRegister) {
                navController.navigate("login_view")
            }
        }
    ) {
        Text(
            text = "Đăng ký",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
    }
}

@Composable
fun ButtonToSignin(navController: NavController) {
    Row (
        modifier = Modifier
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Đã có tài khoản?",
            fontSize = 17.sp
        )

        Spacer(modifier = Modifier.width(5.dp))

        Text(
            text = "Đăng nhập ngay",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Blue,
            modifier = Modifier.clickable{
                navController.navigate("login_view")
            }
        )
    }
}

@Composable
fun RegisterView(navController: NavController){
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xAAFFFFCC))
    ){
        TopTitleRegister()
        RegisterForm()
        RegisterButton(navController)
        ButtonToSignin(navController)
    }
}
