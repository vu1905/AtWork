package com.example.doancoso3.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.doancoso3.model.WorkShifts
import com.example.doancoso3.repository.JobRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class JobViewModel(private val repository: JobRepository = JobRepository()) : ViewModel() {
    //Lay ngay hien tai
    fun getCurrentDate(): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        sdf.timeZone = TimeZone.getTimeZone("Asia/Ho_Chi_Minh")
        return sdf.format(Date())
    }
    val getToday = getCurrentDate()

    //Lay ten cong viec khi nhap du lieu
    var jobName by mutableStateOf("")

    //Set gia tri khi chon muc dich cham cong
    var selectedOption by mutableStateOf("")

    //Set gia tri khi chon hinh thuc cham cong
    var selectedOptionTimekeeping by mutableStateOf("")

    fun saveJob(){
        repository.saveJob(
            jobName = jobName,
            mucDich = selectedOption,
            hinhThuc = selectedOptionTimekeeping,
            ngayBatDau = getToday
        )
    }

    //Thong bao loi neu chua nhap du lieu
    var errMessageJobName by mutableStateOf("*")
    var errMesageOptionTimekeeping by mutableStateOf("*")
    var errMesageOptionJob by mutableStateOf("*")

    fun CreateNewJob(): Boolean {
        var isValid = true
        if(jobName.isBlank()) {
            errMessageJobName = "* Vui lòng nhập tên công việc"
            isValid = false
        } else {
            errMessageJobName = "*"
        }
        if(selectedOption.isBlank()) {
            errMesageOptionJob = "* Bạn chưa có lựa chọn nào"
            isValid = false
        } else {
            errMesageOptionJob = "*"
        }
        if(selectedOptionTimekeeping.isBlank()) {
            errMesageOptionTimekeeping = "* Bạn chưa có lựa chọn nào"
            isValid = false
        } else {
            errMesageOptionTimekeeping = "*"
        }
        return isValid
    }

    //Xu li chon ca lam viec
    var workShifts = mutableStateListOf<WorkShifts>()
        private set

    init {
        workShifts.addAll(
            listOf(
                WorkShifts("1", "Ca sáng", 0),
                WorkShifts("2", "Ca chiều", 0),
                WorkShifts("3", "Ca tối", 0),
                WorkShifts("4", "Ca khuya", 0)
            )
        )
    }

    fun onSalaryChange(shiftId: String, newSalary: Int) {
        val index = workShifts.indexOfFirst { it.id == shiftId }
        if (index != -1) {
            workShifts[index] = workShifts[index].copy(salary = newSalary)
        }
    }

    fun onSelectShift(shiftId: String, salary: Int) {
        val index = workShifts.indexOfFirst { it.id == shiftId }
        if (index != -1) {
            workShifts[index] = workShifts[index].copy(
                isSelected = true,
                salary = salary
            )
        }
    }

    fun getSelectedShifts(): List<WorkShifts> {
        return workShifts.filter { it.isSelected }
    }

}