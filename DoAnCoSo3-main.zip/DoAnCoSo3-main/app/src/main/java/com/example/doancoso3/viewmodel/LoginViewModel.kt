package com.example.doancoso3.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.doancoso3.repository.DangNhapDb

class LoginViewModel(
    private val repository: DangNhapDb = DangNhapDb(),
): ViewModel() {
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var checkedLogin by mutableStateOf(false)
    var errMessageLogin by mutableStateOf("")

    fun login() {
        repository.DangNhap(
            email = email,
            password = password,
            onResult = { success, mesage ->
                if (success) {
                    errMessageLogin = mesage ?: ""
                    checkedLogin = true
                } else {
                    errMessageLogin = mesage ?: ""
                    checkedLogin = false
                }
            }
        )
    }
}