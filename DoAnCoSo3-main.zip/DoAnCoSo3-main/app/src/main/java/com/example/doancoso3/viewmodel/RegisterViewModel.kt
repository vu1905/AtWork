package com.example.doancoso3.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.doancoso3.repository.DangKyDb


class RegisterViewModel(private val repository: DangKyDb = DangKyDb()) : ViewModel() {
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var checkPassword by mutableStateOf("")
    var isRegister by mutableStateOf(false)
    var errRegister by mutableStateOf("")

    fun DangKy() {
        if(checkPassword == password) {
            repository.DangKy(
                email = email,
                password = password,
                onResult = { success, mesage ->
                    if (success) {
                        errRegister = mesage ?: ""
                        isRegister = true
                    } else {
                        errRegister = mesage ?: ""
                        isRegister = false
                    }
                }
            )
        }
    }
}