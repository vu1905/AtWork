package com.example.doancoso3.viewmodel

import androidx.lifecycle.ViewModel
import com.example.doancoso3.repository.TrangChuDb

class TrangChuViewModel(private val repository: TrangChuDb = TrangChuDb()): ViewModel() {
    fun getUserEmail(): String {
        return repository.getUserEmail()
    }
}